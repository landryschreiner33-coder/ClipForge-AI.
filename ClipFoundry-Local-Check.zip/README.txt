Keep ClipFoundry open. Extract this ZIP and double-click Check-ClipFoundry.cmd.
Press Enter for port 8765, or enter the port in your app browser address.
The tool writes a sanitized report JSON next to itself. Send that JSON in chat.
It reads only the local app, with no account tests, uploads, setting changes, installations or administrator access.
It excludes Brain text, account names, paths, tokens, media and raw errors.
Connected flags reflect saved app state; this does not prove a live platform connection.
Validated using portable PowerShell in Linux; native Windows execution is not verified here.
