param([int]$Port = 0, [string]$OutputPath = '')
$ErrorActionPreference = 'Stop'
if ($Port -eq 0) {
    $answer = Read-Host 'App port (press Enter for 8765)'
    if ([string]::IsNullOrWhiteSpace($answer)) { $Port = 8765 }
    elseif (-not [int]::TryParse($answer, [ref]$Port)) { throw 'Enter a numeric port.' }
}
if ($Port -lt 1 -or $Port -gt 65535) { throw 'Port must be between 1 and 65535.' }
$base = 'http://127.0.0.1:' + $Port
$checks = [ordered]@{}
function Read-App([string]$Name, [string]$Path) {
    try {
        $value = Invoke-RestMethod -Uri ($base + $Path) -Method Get -TimeoutSec 20 -MaximumRedirection 0
        $script:checks[$Name] = 'read'
        return $value
    } catch {
        $script:checks[$Name] = 'could_not_read'
        return $null
    }
}
function Select-Fields($Value, [string[]]$Names) {
    $safe = [ordered]@{}
    if ($null -eq $Value) { return $safe }
    foreach ($name in $Names) {
        $property = $Value.PSObject.Properties[$name]
        if ($null -ne $property -and ($null -eq $property.Value -or
            $property.Value -is [bool] -or $property.Value -is [int] -or
            $property.Value -is [long] -or $property.Value -is [double])) {
            $safe[$name] = $property.Value
        }
    }
    return $safe
}
function Enum-Value($Value, [string[]]$Allowed) {
    if ([string]$Value -in $Allowed) { return [string]$Value }
    return 'other'
}
Write-Host 'Reading ClipFoundry on this PC. No account checks, uploads or settings changes.'
$health = Read-App 'health' '/api/health'
$isApp = $null -ne $health -and $null -ne $health.PSObject.Properties['whisper'] -and
    $null -ne $health.PSObject.Properties['cuda'] -and $null -ne $health.PSObject.Properties['ffmpeg']
$report = [ordered]@{ schema_version = 1; collected_utc = [DateTime]::UtcNow.ToString('o');
    app_port = $Port; app_found = $isApp; connection_checks = $checks;
    account_readings = 'Saved app state only; no live platform connection test was run.' }
if ($isApp) {
    $report.health = Select-Fields $health @('nvenc','cuda','whisper_installed','busy','queue')
    $report.health.ffmpeg_found = -not [string]::IsNullOrEmpty([string]$health.ffmpeg)
    $report.health.ffprobe_found = -not [string]::IsNullOrEmpty([string]$health.ffprobe)
    $report.gpu = Select-Fields $health.gpu @('vram_mb','libs_ok')
    $report.transcription = [ordered]@{
        device = Enum-Value $health.whisper.device @('cuda','cpu')
        model = Enum-Value $health.whisper.model @('tiny','base','small','medium','large-v2','large-v3','large-v3-turbo')
        cached = [bool]$health.whisper.cached
        problem_recorded = -not [string]::IsNullOrEmpty([string]$health.whisper.problem)
    }
    $status = Read-App 'autopilot' '/api/autopilot/status'
    if ($null -ne $status) {
        $report.autopilot = Select-Fields $status @('enabled','paused','sources_per_day')
        $report.autopilot.needs_attention = @($status.home.needs_you | ForEach-Object {
            Enum-Value $_.type @('account','connection','gpu','disk','sleep','permission','quota','upload',
                'publishing','worker','storage','access','source','approval','review')
        })
        $report.autopilot.target = Select-Fields $status.target @('daily','processed','published','scheduled')
        $report.autopilot.host = Select-Fields $status.workers.host @('alive','enabled','running')
        $report.autopilot.keep_awake = Enum-Value $status.home.keep_awake @('on','pending','failed','off','unsupported')
        $report.autopilot.next_post = Select-Fields $status.next @('planned_at')
        if ($null -ne $status.next) {
            $report.autopilot.next_post.platform = Enum-Value $status.next.platform @('youtube','tiktok')
            $report.autopilot.next_post.status = Enum-Value $status.next.status @(
                'approved','awaiting_approval','publishing','reconciling','published','failed')
        }
        $report.accounts = [ordered]@{}
        foreach ($platform in @('youtube','tiktok')) {
            $account = $status.platforms.$platform
            $report.accounts[$platform] = Select-Fields $account @('configured','connected','needs_reconnect',
                'analytics','audited','can_direct_post','can_inbox','can_read_stats')
            $report.accounts[$platform].automatic_publishing = Select-Fields $status.home.auto_publish.$platform @(
                'enabled','supported')
        }
        $report.workers = @($status.workers.workers | ForEach-Object {
            $entry = Select-Fields $_ @('heartbeat','stale','progress')
            $entry.status = Enum-Value $_.status @('idle','working','waiting','retrying','error','paused','unavailable')
            $entry
        })
    }
    $integrations = Read-App 'integrations' '/api/integrations'
    $nvidia = @($integrations.cards | Where-Object { $_.id -eq 'nvidia' } | Select-Object -First 1)
    if ($nvidia.Count -gt 0) {
        $value = $nvidia[0].nvidia
        $report.nvidia = Select-Fields $value @('enabled','selected','has_key','opted_in')
        $report.nvidia.mode = Enum-Value $value.mode @('development','production')
        $report.nvidia.setup_problems_recorded = @($value.problems).Count -gt 0
    }
    $office = Read-App 'office_health' '/api/office/health' 
    if ($null -ne $office) {
        $report.system_checks = @($office.checks | ForEach-Object {
            [ordered]@{
                id = Enum-Value $_.id @('scheduler','queue','discovery','gpu','ffmpeg','disk','database',
                    'accounts','audience','quota','media')
                status = Enum-Value $_.status @('healthy','degraded','error','unknown','off','paused')
            }
        })
    }
    $jobs = Read-App 'jobs' '/api/autopilot/jobs?status=running,waiting,retrying,failed&limit=100'
    $report.jobs = @($jobs | Where-Object { $null -ne $_ } | ForEach-Object {
        $entry = Select-Fields $_ @('attempts','progress','created_at','updated_at','run_after')
        $entry.status = Enum-Value $_.status @('running','waiting','retrying','failed')
        $entry.kind = Enum-Value $_.kind @('maintenance','schedule_tick','feed_scan','trend_scan','learn',
            'live_watch','identify_link','hunt_source','analyze_source','package_clip','quality_check','publish',
            'rights_check','live_capture','post_live')
        $entry.wait_reason = Enum-Value $_.wait_reason @('gpu','quota','platform','priority','disk','low_disk',
            'rate_limit','paused','access','stream','future','capacity','network','source_busy','gpu_busy','gpu_failed')
        $entry.error_recorded = -not [string]::IsNullOrEmpty([string]$_.error)
        $entry
    })
}
if ([string]::IsNullOrEmpty($OutputPath)) {
    $OutputPath = Join-Path $PSScriptRoot ('ClipFoundry-report-' + [DateTime]::Now.ToString('yyyyMMdd-HHmmss') + '.json')
}
$report | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $OutputPath -Encoding UTF8
Write-Host ('Saved report: ' + $OutputPath)
if (-not $isApp) { Write-Host 'Keep ClipFoundry open and check its browser port before trying again.' }
Write-Host 'Send only this report JSON to the assistant. Notes, media, tokens, names, paths and raw errors are excluded.'
